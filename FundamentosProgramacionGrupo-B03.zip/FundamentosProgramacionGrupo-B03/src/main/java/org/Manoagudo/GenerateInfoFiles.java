package org.Manoagudo;

public class GenerateInfoFiles {
    public static void main(String[] args) {

        generateProductList();
        generateVendorList();
        generateSalesRecords();
    }
        private static void generateProductList() {
            // Implementación para generar archivo de lista de productos
        }

        private static void generateVendorList() {
            // Implementación para generar archivo de lista de vendedores
        }

        private static void generateSalesRecords() {
            // Implementación para generar archivo de registros de ventas
        }

    }

